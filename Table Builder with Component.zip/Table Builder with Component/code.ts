/// <reference types="@figma/plugin-typings" />

let selectedComponentId: string | null = null;
let targetTextNodeId: string | null = null;
let excelHeaders: string[] = [];
let excelRows: any[][] = [];
let targetTextNodeName: string | null = null;

figma.showUI(__html__, { width: 400, height: 600 });

function validateComponentSelection() {
  const selection = figma.currentPage.selection;
  if (selection.length !== 1 || (selection[0].type !== "COMPONENT" && selection[0].type !== "COMPONENT_SET")) {
    figma.ui.postMessage({ type: "error", message: "Please select a single component or component set." });
    return;
  }

  const component = selection[0] as ComponentNode | ComponentSetNode;
  const textNodes = component.findAll(node => node.type === "TEXT") as TextNode[];

  let targetText: TextNode | null = null;
  if (textNodes.length === 1) {
    targetText = textNodes[0];
  } else if (textNodes.length > 1) {
    targetText = textNodes.find(n => n.name === "Input") || null;
    if (!targetText) {
      figma.ui.postMessage({
        type: "error",
        message: "Multiple text layers found. No layer named 'Input' was found. Please name your editable text layer 'Input'."
      });
      return;
    }
  } else {
    figma.ui.postMessage({ type: "error", message: "No text layers found in the selected component." });
    return;
  }

  selectedComponentId = component.id;
  targetTextNodeId = targetText.id;
  targetTextNodeName = targetText.name;
  figma.ui.postMessage({
    type: "component-valid",
    componentId: selectedComponentId,
    textNodeId: targetTextNodeId,
    textNodeName: targetTextNodeName,
    info: `Component valid. Using text layer: '${targetText.name}'.`
  });
}

figma.ui.onmessage = async (msg) => {
  if (msg.type === "validate-component") {
    validateComponentSelection();
  }
  if (msg.type === "step1-continue") {
    selectedComponentId = msg.componentId;
    targetTextNodeId = msg.textNodeId;
    targetTextNodeName = msg.textNodeName;
    figma.ui.postMessage({ type: "continue-to-excel" });
  }
  if (msg.type === "excel-data") {
    excelHeaders = msg.headers;
    excelRows = msg.rows;
    figma.ui.postMessage({ type: "excel-ok", headers: excelHeaders, rows: excelRows });
  }
  if (msg.type === "generate-table") {
    const selectedCols = msg.selectedCols;
    const numRows = msg.numRows;
    if (!selectedComponentId || !targetTextNodeId || !targetTextNodeName) {
      figma.ui.postMessage({ type: "error", message: "Component or text node not set. Please restart the plugin." });
      return;
    }
    if (!Array.isArray(selectedCols) || selectedCols.length === 0) {
      figma.ui.postMessage({ type: "error", message: "No columns selected." });
      return;
    }
    if (!numRows || numRows < 1 || numRows > excelRows.length) {
      figma.ui.postMessage({ type: "error", message: "Invalid number of rows." });
      return;
    }
    let componentNode: ComponentNode | ComponentSetNode | null = null;
    try {
      componentNode = (await figma.getNodeByIdAsync(selectedComponentId)) as ComponentNode | ComponentSetNode | null;
    } catch (e) {
      figma.ui.postMessage({ type: "error", message: "Error looking up component node." });
      return;
    }
    if (!componentNode || (componentNode.type !== "COMPONENT" && componentNode.type !== "COMPONENT_SET")) {
      figma.ui.postMessage({ type: "error", message: "Component not found or invalid." });
      return;
    }
    const tableFrame = figma.createFrame();
    tableFrame.layoutMode = "VERTICAL";
    tableFrame.primaryAxisAlignItems = "MIN";
    tableFrame.counterAxisAlignItems = "MIN";
    tableFrame.name = "Generated Table";
    tableFrame.primaryAxisSizingMode = "AUTO";
    tableFrame.counterAxisSizingMode = "AUTO";
    for (let rowIdx = 0; rowIdx < numRows; rowIdx++) {
      const rowFrame = figma.createFrame();
      rowFrame.layoutMode = "HORIZONTAL";
      rowFrame.primaryAxisAlignItems = "MIN";
      rowFrame.counterAxisAlignItems = "MIN";
      rowFrame.name = `Row ${rowIdx + 1}`;
      rowFrame.primaryAxisSizingMode = "AUTO";
      rowFrame.counterAxisSizingMode = "AUTO";
      for (const colIdx of selectedCols) {
        let instance: InstanceNode;
        if (componentNode.type === "COMPONENT_SET") {
          const firstComponent = componentNode.children.find(child => child.type === "COMPONENT") as ComponentNode;
          if (!firstComponent) continue;
          instance = firstComponent.createInstance();
        } else {
          instance = componentNode.createInstance();
        }
        const textNode = instance.findOne(n => n.type === "TEXT" && n.name === targetTextNodeName) as TextNode | null;
        if (!textNode) {
          figma.ui.postMessage({ type: "error", message: "Text node not found in instance." });
          continue;
        }
        const value = excelRows[rowIdx]?.[colIdx];
        try {
          await figma.loadFontAsync({ family: "Roboto", style: "Regular" });
          textNode.characters = value !== undefined && value !== null ? String(value) : "";
        } catch (e) {
          figma.ui.postMessage({ type: "error", message: "Font load failed." });
          continue;
        }
        rowFrame.appendChild(instance);
      }
      tableFrame.appendChild(rowFrame);
    }
    tableFrame.x = figma.viewport.center.x;
    tableFrame.y = figma.viewport.center.y;
    figma.currentPage.appendChild(tableFrame);
    figma.currentPage.selection = [tableFrame];
    figma.viewport.scrollAndZoomIntoView([tableFrame]);
    figma.ui.postMessage({ type: "complete" });
  }
  if (msg.type === "exit") {
    figma.closePlugin();
  }
};
